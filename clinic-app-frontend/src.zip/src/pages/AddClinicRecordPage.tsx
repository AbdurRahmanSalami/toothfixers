import React, { useState } from "react";
import Navbar from "../components/Navbar";
import Footer from "../components/Footer";
import { createClinicRecord } from "../api/clinicRecordApi";

const AddClinicRecordsPage: React.FC = () => {
  const [formData, setFormData] = useState({
    clinicDate: "",
    ailmentDescription: "",
    medicinePrescribed: "",
    procedureUndertaken: "",
    nextAppointment: "",
  });

  const [message, setMessage] = useState<string | null>(null);
  const [messageType, setMessageType] = useState<"success" | "error" | null>(null);

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      const response = await createClinicRecord(formData);
      console.log("Clinic record created:", response);

      // Reset form data after successful submission
      setFormData({
        clinicDate: "",
        ailmentDescription: "",
        medicinePrescribed: "",
        procedureUndertaken: "",
        nextAppointment: "",
      });

      // Set success message
      setMessage("Clinic record created successfully!");
      setMessageType("success");

      // Clear message after 5 seconds
      setTimeout(() => {
        setMessage(null);
        setMessageType(null);
      }, 5000);

    } catch (error) {
      console.error("Error adding clinic record:", error);

      // Set error message
      setMessage("Error adding clinic record. Please try again.");
      setMessageType("error");

      // Clear message after 5 seconds
      setTimeout(() => {
        setMessage(null);
        setMessageType(null);
      }, 5000);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Navbar />

      <main className="flex-grow container mx-auto px-6 py-16 flex flex-col items-center justify-center text-center">
        <p className="text-3xl font-bold text-green-800 mb-4">Add Clinic Record</p>
        {message && (
          <div className={`mb-4 p-4 rounded ${messageType === 'success' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
            {message}
          </div>
        )}
        <form onSubmit={handleSubmit} className="bg-white p-6 rounded shadow-md w-full max-w-md">
          <div className="mb-4">
            <label className="block text-gray-700 mb-2" htmlFor="clinicDate">Clinic Date</label>
            <input
              type="date"
              id="clinicDate"
              name="clinicDate"
              value={formData.clinicDate}
              onChange={handleChange}
              className="w-full px-3 py-2 border rounded"
              required
            />
          </div>
          <div className="mb-4">
            <label className="block text-gray-700 mb-2" htmlFor="ailmentDescription">Nature of Ailment</label>
            <input
              id="ailmentDescription"
              name="ailmentDescription"
              value={formData.ailmentDescription}
              onChange={handleChange}
              className="w-full px-3 py-2 border rounded"
              required
            />
          </div>
          <div className="mb-4">
            <label className="block text-gray-700 mb-2" htmlFor="medicinePrescribed">Medicine Prescribed</label>
            <input
              id="medicinePrescribed"
              name="medicinePrescribed"
              value={formData.medicinePrescribed}
              onChange={handleChange}
              className="w-full px-3 py-2 border rounded"
            />
          </div>
          <div className="mb-4">
            <label className="block text-gray-700 mb-2" htmlFor="procedureUndertaken">Procedure Undertaken</label>
            <input
              id="procedureUndertaken"
              name="procedureUndertaken"
              value={formData.procedureUndertaken}
              onChange={handleChange}
              className="w-full px-3 py-2 border rounded"
            />
          </div>
          <div className="mb-4">
            <label className="block text-gray-700 mb-2" htmlFor="nextAppointment">Date of Next Appointment</label>
            <input
              type="date"
              id="nextAppointment"
              name="nextAppointment"
              value={formData.nextAppointment}
              onChange={handleChange}
              className="w-full px-3 py-2 border rounded"
            />
          </div>
          <div className="mb-4">
            <button
              type="submit"
              className="px-6 py-3 bg-green-600 text-white rounded-lg shadow-md hover:bg-green-700 transition duration-200 w-full"
            >
              Add Clinic Record
            </button>
          </div>
        </form>
      </main>

      <Footer />
    </div>
  );
};

export default AddClinicRecordsPage;
