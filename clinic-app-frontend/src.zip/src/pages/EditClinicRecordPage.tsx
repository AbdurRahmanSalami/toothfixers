import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';

const AddClinicalRecordPage: React.FC = () => {
  const [formData, setFormData] = useState({
    patientId: '',
    clinicDate: '',
    natureOfAilment: '',
    medicinePrescribed: '',
    procedureUndertaken: '',
    dateOfNextAppointment: '',
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle form submission
    console.log('Clinical record data:', formData);
    // Example of clearing form data after submission
    setFormData({
      patientId: '',
      clinicDate: '',
      natureOfAilment: '',
      medicinePrescribed: '',
      procedureUndertaken: '',
      dateOfNextAppointment: '',
    });
  };

  return (
    <div className="flex flex-col min-h-screen bg-gray-100">
            <Navbar/>
      {/* Main Content */}
      <main className="flex-1 container mx-auto py-8 px-4">
        <div className="max-w-md mx-auto bg-white p-6 rounded-lg shadow-md">
          <h2 className="text-2xl font-bold text-green-700 mb-4 text-center">Add Clinical Record</h2>
          <form onSubmit={handleSubmit}>
            {/* Form Inputs */}
            {/* ... */}
            <button
              type="submit"
              className="w-full bg-green-600 text-white py-2 px-4 rounded-md hover:bg-green-700 transition duration-200"
            >
              Add Clinical Record
            </button>
          </form>
        </div>

        {/* Edit Clinic Record Button */}
        <div className="flex justify-center mt-4">
          <Link
            to={`/edit-clinic-record/${formData.patientId}`}  // Replace formData.patientId with your identifier
            className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
          >
            Edit Clinic Record
          </Link>
        </div>
      </main>

      <Footer/>
    </div>
  );
};

export default AddClinicalRecordPage;
