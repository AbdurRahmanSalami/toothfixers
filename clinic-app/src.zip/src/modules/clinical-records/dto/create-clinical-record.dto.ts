/* eslint-disable prettier/prettier */
import { IsDate, IsNotEmpty, IsOptional, IsString } from 'class-validator';
import { Type } from 'class-transformer';

export class CreateClinicalRecordDto {
  @IsNotEmpty()
  @IsDate()
  @Type(() => Date)
  clinicDate: Date;

  @IsNotEmpty()
  @IsString()
  natureOfAilment: string;

  @IsOptional()
  @IsString()
  medicinePrescribed?: string;

  @IsOptional()
  @IsString()
  procedureUndertaken?: string;

  @IsOptional()
  @IsDate()
  @Type(() => Date)
  dateOfNextAppointment?: Date;

}